-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2024 at 11:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `applicants`
--

CREATE TABLE `applicants` (
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `jobname` varchar(50) NOT NULL,
  `eid` int(50) NOT NULL,
  `uid` int(50) NOT NULL,
  `jid` int(10) NOT NULL,
  `description` varchar(500) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `applicants`
--

INSERT INTO `applicants` (`username`, `email`, `jobname`, `eid`, `uid`, `jid`, `description`, `status`) VALUES
('moose', 'tmosesvaiphei2504@gmail.com', 'Painting wall', 1, 2, 19, 'Painting of a house.', 'pending'),
('moose', 'tmosesvaiphei2504@gmail.com', 'Delivery', 1, 2, 20, 'Delivery of goods to a store.', 'pending'),
('moose', 'tmosesvaiphei2504@gmail.com', 'Moving', 1, 2, 27, 'Moving of furnitures', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `jobname` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `eid` int(50) NOT NULL,
  `jid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`jobname`, `description`, `eid`, `jid`) VALUES
('Delivery', 'Delivery of goods to a store.', 2, 18),
('Painting wall', 'Painting of a house.', 1, 19),
('Delivery', 'Delivery of goods to a store.', 1, 20),
('Moving', 'Moving of furnitures', 1, 27),
('Moving', 'Moving of furnitures,', 2, 28),
('Painting wall', 'Painting of a wall.', 2, 29);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `uid` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `email`, `password`, `uid`) VALUES
('joe', 'joe@gmail.com', '1234567890', 1),
('moose', 'tmosesvaiphei2504@gmail.com', '1234567890', 2),
('poopoo', 'adf@gmail.com', '1234567890', 3),
('peepee', 'qwer@gmail.com', '$2y$10$TlGDtRJKJ/FKhL2SfO8LHeCs1iX06fy9rblHUCivVCw', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`jid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `jid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
